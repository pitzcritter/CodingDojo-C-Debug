﻿using System;
using System.Collections.Generic;
using System.Diagnostics;//used with error() below.....
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http; // Added
using Microsoft.AspNetCore.Identity; // hasher...
using TheWallEntitiyFrameWork.Models;
// using Microsoft.Extensions.Options;
// using MySql.Data.MySqlClient; // dotnet add package MySql.Data --version 6.10.6 

namespace TheWallEntitiyFrameWork.Controllers
{
    public class LoginController : Controller
    {
        private MyDbContext _dbContext;
        public LoginController(MyDbContext context)
        {
            _dbContext = context;
        }

        [HttpGet("")] 
        public IActionResult Index()
        {
            //return View(_dbContext.loginusers.ToList());
            return View();
        }

        [HttpPost("register")] 
        public IActionResult Register(RegisterUserCl user)
        {
            if(ModelState.IsValid)
            {
                RegisterUser(user);
                return RedirectToAction("Index", "Wall");
            }
            return View("Index");
        }

        //[HttpPost]
        [HttpPost("login")]
        public IActionResult Login(LoginUserCl user)
        {            
            //List<Dictionary<string,object>> users = DbConnector.Query($"SELECT id, password FROM users WHERE email = '{user.LogEmail}'");
///Error here!!!!!
            var thisUser = _dbContext.users.SingleOrDefault(x => x.Email == user.Email);

            PasswordHasher<LoginUserCl> hasher = new PasswordHasher<LoginUserCl>();
            //user exists
            if((user.LogPassword == null) || hasher.VerifyHashedPassword(user, (string)thisUser.Password, user.LogPassword) == 0)
 //!!!need test for existing record!!!//if((users.Count == 0 || user.LogPassword == null) || hasher.VerifyHashedPassword(user, (string)users[0]["password"], user.LogPassword) == 0)
            {
                ModelState.AddModelError("LogEmail", "Invalid Email/Password");
            }
            if(ModelState.IsValid)
            {
                HttpContext.Session.SetInt32("id", (int)thisUser.Id);
                return RedirectToAction("Index", "Wall");
            }
            return View("Index");
        }
        
        [HttpGet("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        public void RegisterUser(RegisterUserCl user)
        {
            PasswordHasher<RegisterUserCl> hasher = new PasswordHasher<RegisterUserCl>();
            string hashedPW = hasher.HashPassword(user, user.Password);

            UserCl newUser = new UserCl(user.First_name, user.Last_Name, user.Email, hashedPW, DateTime.Now,DateTime.Now);
            _dbContext.users.Add(newUser);
            _dbContext.SaveChanges();
            
            int thisId = _dbContext.users.SingleOrDefault(x => x.Email == user.Email).Id;            
            HttpContext.Session.SetInt32("id", Convert.ToInt32(thisId));

            //string query = $@"INSERT INTO users (first_name, last_name, email, password, created_at, updated_at) VALUES ('{user.First_Name}', '{user.LastName}', '{user.Email}', '{hashed}', NOW(), NOW()); SELECT LAST_INSERT_ID() as id";
            //HttpContext.Session.SetInt32("id", Convert.ToInt32(DbConnector.Query(query)[0]["id"]));
        }

        //[HttpGet("about")]
        // public IActionResult About()
        // {
        //     ViewData["Message"] = "Your application description page.";
        //     return View();
        // }

        // // [HttpGet("contact")]
        // public IActionResult Contact()
        // {
        //     ViewData["Message"] = "Your contact page.";

        //     return View();
        // }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
