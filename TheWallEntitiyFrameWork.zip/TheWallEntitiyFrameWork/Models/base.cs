namespace TheWallEntitiyFrameWork.Models
{
    public abstract class BaseEntity {}
}
