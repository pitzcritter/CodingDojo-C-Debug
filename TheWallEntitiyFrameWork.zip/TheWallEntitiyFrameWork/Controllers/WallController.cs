﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using TheWallEntitiyFrameWork.Models;
using Microsoft.AspNetCore.Http; // Added

namespace TheWallEntitiyFrameWork.Controllers
{
    public class WallController : Controller
    {        
        private MyDbContext _dbContext;
        public WallController(MyDbContext context)
        {
            _dbContext = context;
        }
        
        [HttpGet("dashboard")]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetInt32("id") == null)
                return RedirectToAction("Index", "User");
            ViewBag.Messages = GetAllMessages();
            ViewBag.Comments = GetAllComments();
            //ViewBag.User = DbConnector.Query($"SELECT first_name FROM users WHERE users.id = {(int)HttpContext.Session.GetInt32("id")}")[0];
            ViewBag.User = _dbContext.users.SingleOrDefault(x => x.Id == (int)HttpContext.Session.GetInt32("id"));
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        [HttpPost]
        [Route("messages/create")]
        public IActionResult CreateMessage(WallModels wallModel)
        {
            if(ModelState.IsValid)
            {
                 //ar thisUserID = _dbContext.users.SingleOrDefault(x => x.Id == (int)HttpContext.Session.GetInt32("id")).Id;

                MessagesCl thisMessage = new MessagesCl//()
                {
                    Message = wallModel.MessagePost.Message,
                    User_Id = (int)HttpContext.Session.GetInt32("id"),
                    Created_At= DateTime.Now,
                    Updated_At = DateTime.Now
                };

            _dbContext.messages.Add(thisMessage);
            _dbContext.SaveChanges();

                // insert a message
                // string query = $@"INSERT INTO messages (message, user_id, created_at, updated_at)
                //                   VALUES ('{wallModel.MessagePost.Message}', {(int)HttpContext.Session.GetInt32("id")}, NOW(), NOW())";
                //DbConnector.Execute(query);
                return RedirectToAction("Index");
            }
            return View("Index");
        }
        [HttpPost]
        [Route("comments/create/")]
        public IActionResult CreateComment(WallModels wallModel)
        {
            if(ModelState.IsValid)
            {
                CommentCl thisComment = new CommentCl()
                {
                    Comment = wallModel.CommentPost.Comment,
                    //User_Id = (int)HttpContext.Session.GetInt32("id"),
                    Message_Id = wallModel.CommentPost.Message_Id,
                    User_Id = wallModel.CommentPost.User_Id,
                    Created_At= DateTime.Now,
                    Updated_At = DateTime.Now
                };

                _dbContext.comments.Add(thisComment);
                _dbContext.SaveChanges();

                // insert a message
                // string query = $@"INSERT INTO comments (comment, user_id, message_id, created_at, updated_at)
                //                   VALUES ('{wallModel.CommentPost.Comment}', {(int)HttpContext.Session.GetInt32("id")}, '{wallModel.CommentPost.Message_Id}', NOW(), NOW())";
                // DbConnector.Execute(query);                
                return RedirectToAction("Index");
            }
            return View("Index");
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";
            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        //public List<Dictionary<string, object>> GetAllMessages()
        // public List<JoinedMessagesCl> GetAllMessages()
        // {
        //     var theseUsers = _dbContext.users;
        //     var theseMessages = _dbContext.messages;//.ToList();

        //     var joinedMessages = (from thisUser in theseUsers join thisMessage in theseMessages on thisUser.Id equals thisMessage.User_Id orderby thisUser.Id 
        //     select new {  
        //         user_id = thisUser.Id,
        //         message_id = thisMessage.Id,
        //         First_Name=thisUser.First_Name,
        //         Last_Name=thisUser.Last_Name,
        //         Message=thisMessage.Message,
        //         Created_At=thisMessage.Created_At
        //     }).ToList();
            
        //     List<JoinedMessagesCl> joinedList = new List<JoinedMessagesCl>();            
        //     foreach (var item in joinedMessages)
        //     {
        //         JoinedMessagesCl thisMsg = new JoinedMessagesCl();
        //             thisMsg.User_Id = item.user_id;
        //             thisMsg.First_Name = item.First_Name;
        //             thisMsg.Last_Name = item.Last_Name;
        //             thisMsg.Id = item.message_id;
        //             thisMsg.Message = item.Message;
        //             thisMsg.Created_At = item.Created_At;
        //         joinedList.Add(thisMsg);
        //     }
        //     return joinedList;
        //     // string query = @"SELECT messages.id AS message_id, messages.message, messages.created_at, users.first_name, users.last_name 
        //     //                  FROM messages JOIN users ON messages.user_id = users.id";
        //     // return DbConnector.Query(query);
        // }


        public List<Dictionary<string,object>> GetAllMessages()
        {
            var theseUsers = _dbContext.users;
            var theseMessages = _dbContext.messages;//.ToList();

            var joinedMessages = (from thisUser in theseUsers join thisMessage in theseMessages on thisUser.Id equals thisMessage.User_Id orderby thisUser.Id 
            select new {  
                user_id = thisUser.Id,
                message_id = thisMessage.Id,
                First_Name=thisUser.First_Name,
                Last_Name=thisUser.Last_Name,
                Message=thisMessage.Message,
                Created_At=thisMessage.Created_At
            }).ToList();
            
            List<Dictionary<string,object>> joinedList = new List<Dictionary<string,object>>();
            foreach (var item in joinedMessages)
            {
                Dictionary<string,object> thisMsg = new Dictionary<string,object>()
                {
                    {"User_Id" , item.user_id},
                    {"First_Name" , item.First_Name},
                    {"Last_Name" , item.Last_Name},
                    {"Id" , item.message_id},
                    {"Message" , item.Message},
                    {"Created_At" , item.Created_At}
                };
                joinedList.Add(thisMsg);
            }
            return joinedList;
        }


        public List<Dictionary<string,object>> GetAllComments()
        {
            var theseUsers = _dbContext.users;
            var theseComments = _dbContext.comments;//.ToList();

            var joinedComments = (from thisUser in theseUsers join thisComment in theseComments on thisUser.Id equals thisComment.User_Id orderby thisUser.Id 
            select new {  
                user_id = thisUser.Id,
                message_id = thisComment.Message_Id,
                Comment_id = thisComment.Id,
                First_Name=thisUser.First_Name,
                Last_Name=thisUser.Last_Name,
                Comment=thisComment.Comment,
                Created_At=thisComment.Created_At
            }).ToList();
            
            List<Dictionary<string,object>> joinedList = new List<Dictionary<string,object>>();
            foreach (var item in joinedComments)
            {
                Dictionary<string,object> thisMsg = new Dictionary<string,object>()
                {
                    {"User_Id" , item.user_id},
                    {"Message_Id" , item.message_id},
                    {"First_Name" , item.First_Name},
                    {"Last_Name" , item.Last_Name},
                    {"Id" , item.Comment_id},
                    {"Comment" , item.Comment},
                    {"Created_At" , item.Created_At}
                };
                joinedList.Add(thisMsg);
            }
            return joinedList;
        }

        // public List<Dictionary<string, object>> GetAllComments()
        // {
        //     var theseUsers = _dbContext.users;
        //     var theseComments = _dbContext.comments;//.ToList();

        //     foreach (var item in theseComments)
        //     {
                
        //     }
        //     string query = $@"SELECT comments.id AS comment_id, comments.comment, comments.created_at, users.first_name, users.last_name, comments.message_id
        //                       FROM comments JOIN messages ON comments.message_id = messages.id
        //                       JOIN users ON comments.user_id = users.id";
        //     return DbConnector.Query(query);
        // }

    }
}
