using System;
using System.ComponentModel.DataAnnotations;
using System. Collections.Generic;

namespace TheWallEntitiyFrameWork.Models
{
    public class User
    {
        [Key] // used in EF
        public int Id {get;set;}

        [Required]
        [Display(Name="First Name")]
        public string First_Name {get;set;}

        [Required]
        [Display(Name="Last Name")]
        public string Last_Name {get;set;}

        [Required]
        [Display(Name="Email")]
        [EmailAddress]

        public string Email {get;set;}

        [Required]
        [Display(Name="Password")]
        [DataType(DataType.Password)]
        public string Password {get;set;}

        public DateTime Created_At {get;set;}
    }
}