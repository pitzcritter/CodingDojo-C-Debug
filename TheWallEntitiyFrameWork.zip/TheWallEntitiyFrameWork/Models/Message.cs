using System.ComponentModel.DataAnnotations;
using System;

namespace TheWallEntitiyFrameWork.Models
{
    public class MessageCl: BaseEntity
    {
        [Display(Name="Message")]
        [Required]
        public string Message {get;set;}
    }
    public class CommentCl: BaseEntity
    {
        public int Id {get;set;}
        [Display(Name="Comment on this Post")]
        [Required]
        public string Comment {get;set;}
        public int Message_Id {get;set;}
        public int User_Id {get;set;}
        public DateTime Created_At {get;set;}
        public DateTime Updated_At {get;set;}
    }

    public class WallModels: BaseEntity
    {
        public MessageCl MessagePost {get;set;}
        public CommentCl CommentPost {get;set;}
    }

    public class MessagesCl: BaseEntity // To insert to thewall.messages datatable from WallController.
    {
        [Key]
        public int Id{get;set;}
        public string Message {get;set;}
        public DateTime Created_At {get;set;}
        public DateTime Updated_At {get;set;}
        public int User_Id {get;set;}
    }
    public class JoinedMessagesCl: MessagesCl
    {
        public string First_Name;
        public string Last_Name;        
    } 
}

