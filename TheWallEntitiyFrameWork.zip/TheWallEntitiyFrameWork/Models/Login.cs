using System.ComponentModel.DataAnnotations;
using System;

namespace TheWallEntitiyFrameWork.Models
{
  public class UserCl//: BaseEntity
    {
        //[Required]
        [Key]
        public int Id {get; set;}

        [Required]
        [Display(Name="First Name")]
        [MinLength(2)]
        public string First_Name {get;set;}

        [Required]
        [Display(Name="Last Name")]
        [MinLength(2)]
        public string Last_Name {get;set;}

        [Required]
        [DataType(DataType.EmailAddress)]
        //[FieldExists("email")] // no longer available   https://msdn.microsoft.com/en-us/library/system.componentmodel.dataannotations(v=vs.110).aspx
        [EmailAddress(ErrorMessage="Invalid Email")]
        [Display(Name="Email")]
        public string Email {get;set;}

        // [Required]
        [Display(Name="Password")]
        // [MinLength(8)]
        // [DataType(DataType.Password)]

        [Required(ErrorMessage = "Password is required")]
        [StringLength(50, ErrorMessage = "Must be between 5 and 50 characters", MinimumLength = 5)]
        [DataType(DataType.Password,ErrorMessage = "Password is required")]
        public string Password {get;set;}

        public DateTime Created_At {get;set;}
        public DateTime Updated_At {get;set;}

        public UserCl(string first_name, string last_name, string email, string hashedPW, DateTime? created = null, DateTime? updated = null)
        {
            First_Name = first_name;
            Last_Name=last_name;
            Email=email;
            Password=hashedPW
            if (created != null)
                Created_At = created;
            if (updated != null)
                Updated_At = updated;
        }
    }

    public class RegisterUserCl: UserCl
    {
        public RegisterUserCl(UserClOptions options): base(options) {}
        
        [Required(ErrorMessage = "Password is required")]
        [Display(Name="Confirm")]
        [StringLength(50, ErrorMessage = "Must be between 5 and 50 characters", MinimumLength = 5)]
        [DataType(DataType.Password,ErrorMessage = "Password is required")]
        [Compare("Password",ErrorMessage = "Passwords don't match")]
        public string Confirm {get;set;}
    }
    public class InsertUserCl //Can delete....
    {
        [Key]
        public int Id {get;set;}

        [Required]
        [Display(Name="First Name")]
        [MinLength(2)]
        public string First_Name {get;set;}

        [Required]
        [Display(Name="Last Name")]
        [MinLength(2)]
        public string Last_Name {get;set;}

        [Required]
        [DataType(DataType.EmailAddress)]
        //[FieldExists("email")] // no longer available   https://msdn.microsoft.com/en-us/library/system.componentmodel.dataannotations(v=vs.110).aspx
        [EmailAddress(ErrorMessage="Invalid Email")]
        [Display(Name="Email")]
        public string Email {get;set;}

        // [Required]
        [Display(Name="Password")]
        // [MinLength(8)]
        // [DataType(DataType.Password)]

        [Required(ErrorMessage = "Password is required")]
        [StringLength(50, ErrorMessage = "Must be between 5 and 50 characters", MinimumLength = 5)]
        [DataType(DataType.Password,ErrorMessage = "Password is required")]
        public string Password {get;set;}        
        public DateTime Created_At {get;set;}
        public DateTime Updated_At {get;set;}
    }
    public class LoginUserCl: UserCl//BaseEntity
    {
        public LoginUserCl(UserClOptions options): base(options) {}
        // [Required]
        // [DataType(DataType.EmailAddress)]
        // [Display(Name="Email")]
        // [EmailAddress(ErrorMessage="Invalid Email")]
        // public string LogEmail {get;set;}

        // [Required]
        // [Display(Name="Password")]
        // [DataType(DataType.Password)]
        public string LogPassword{get;set;}
    }
    public class HomePageUsers: BaseEntity
    {
        public RegisterUserCl Register {get;set;}
        public LoginUserCl Login {get;set;}
    }   
}