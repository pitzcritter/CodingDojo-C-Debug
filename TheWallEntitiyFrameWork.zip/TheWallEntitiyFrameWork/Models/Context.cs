using Microsoft.EntityFrameworkCore;

namespace TheWallEntitiyFrameWork.Models
{
    public class MyDbContext: DbContext
    {
        public MyDbContext(DbContextOptions options): base(options) {}

        public DbSet<UserCl> users {get; set;}
        public DbSet<RegisterUserCl> registerusers {get; set;}
        public DbSet<LoginUserCl> loginusers {get; set;}
        public DbSet<MessagesCl> messages {get; set;}
        public DbSet<CommentCl> comments {get; set;}
    }
}